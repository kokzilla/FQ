import { defineEventHandler } from 'h3'
import { prisma } from '../../utils/prisma'
import { isDbReady } from '../../utils/dbState'

const INITIAL_BUILDINGS = [
  {
    "id": "b-b01",
    "code": "B01",
    "name": "อาคาร 1",
    "floors": 3,
    "description": "สังกัด สถาบันวิจัยและพัฒนา",
    "staffs": [
      {
        "id": "s-b01-1",
        "staffName": "นางประยงค์  นันกลาง"
      }
    ]
  },
  {
    "id": "b-b02",
    "code": "B02",
    "name": "อาคาร 2",
    "floors": 3,
    "description": "สังกัด คณะวิทยาศาสตร์ (ห้องพยาบาล)",
    "staffs": [
      {
        "id": "s-b02-1",
        "staffName": "นางสาวจันทร์จิรา  เชิดกลิ่น"
      }
    ]
  },
  {
    "id": "b-b05",
    "code": "B05",
    "name": "อาคาร 5",
    "floors": 3,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b05-1",
        "staffName": "นางสาวปัทมา  ยอนรัมย์"
      }
    ]
  },
  {
    "id": "b-b06",
    "code": "B06",
    "name": "อาคาร 6",
    "floors": 3,
    "description": "สังกัด คณะมนุษยศาสตร์และสังคมศาสตร์",
    "staffs": [
      {
        "id": "s-b06-1",
        "staffName": "นางสาวสุณี  เกริงรัมย์"
      }
    ]
  },
  {
    "id": "b-b07",
    "code": "B07",
    "name": "อาคาร 7",
    "floors": 3,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b07-1",
        "staffName": "นางสาวพิมพ์วลัญช์  เชียงพฤกษ์"
      }
    ]
  },
  {
    "id": "b-b10",
    "code": "B10",
    "name": "อาคาร 10",
    "floors": 3,
    "description": "สังกัด คณะครุศาสตร์",
    "staffs": [
      {
        "id": "s-b10-1",
        "staffName": "นางสาวตวงลักษณ์  นิลแก้ว"
      }
    ]
  },
  {
    "id": "b-b12",
    "code": "B12",
    "name": "อาคาร 12 (ศูนย์วิทยาศาสตร์และวิทยาศาสตร์ประยุกต์)",
    "floors": 4,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b12-1",
        "staffName": "นายพงศ์ศรัณย์  เติมเทียน"
      },
      {
        "id": "s-b12-2",
        "staffName": "นางสาวมะปราง  เปาป่า"
      }
    ]
  },
  {
    "id": "b-b13",
    "code": "B13",
    "name": "อาคาร 13 (คณะพยาบาลศาสตร์)",
    "floors": 4,
    "description": "สังกัด คณะพยาบาลศาสตร์",
    "staffs": [
      {
        "id": "s-b13-1",
        "staffName": "นางสาวสุวรรณา  ทองสม"
      }
    ]
  },
  {
    "id": "b-b14",
    "code": "B14",
    "name": "อาคาร 14",
    "floors": 3,
    "description": "สังกัด คณะครุศาสตร์ + คณะมนุษยศาสตร์ฯ (สาขาวิชานาฏศิลป์+ดนตรี)",
    "staffs": [
      {
        "id": "s-b14-1",
        "staffName": "นางสาวมาลี  สิงห์คำ"
      }
    ]
  },
  {
    "id": "b-b15",
    "code": "B15",
    "name": "อาคาร 15 (อาคารเฉลิมพระเกียรติ 50 พรรษามหาวชิราลงกรณ์)",
    "floors": 9,
    "description": "สังกัด สำนักงานอธิการบดี + บัณฑิตวิทยาลัย",
    "staffs": [
      {
        "id": "s-b15-1",
        "staffName": "นางบุญมี  จันลา"
      },
      {
        "id": "s-b15-2",
        "staffName": "นางสาวธัญรัศม์  เครืองรัมย์"
      },
      {
        "id": "s-b15-3",
        "staffName": "นางสาวพชรภรณ์  ลีประโคน"
      },
      {
        "id": "s-b15-4",
        "staffName": "นางรุจิกาญจน์  สิงห์คำ"
      }
    ]
  },
  {
    "id": "b-b16",
    "code": "B16",
    "name": "อาคาร 16 (อาคารสิ่งทอ)",
    "floors": 2,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b16-1",
        "staffName": "นางกชพร  ชุบรัมย์"
      }
    ]
  },
  {
    "id": "b-b17",
    "code": "B17",
    "name": "อาคาร 17 (อาคารนวัตปัญญา)",
    "floors": 4,
    "description": "สังกัด สำนักวิทยบริการและเทคโนโลยีสารสนเทศ",
    "staffs": [
      {
        "id": "s-b17-1",
        "staffName": "นางสาวกรวรรณ  จันทรภูมิ"
      },
      {
        "id": "s-b17-2",
        "staffName": "นางณัฐชยา  ปรีชารัมย์"
      }
    ]
  },
  {
    "id": "b-b18",
    "code": "B18",
    "name": "อาคาร 18 (อาคารเฉลิมพระเกียรติ 7 รอบ พระชนมพรรษา)",
    "floors": 5,
    "description": "สังกัด คณะเทคโนโลยีอุตสาหกรรม",
    "staffs": [
      {
        "id": "s-b18-1",
        "staffName": "นางทองสุข  คิดการ"
      },
      {
        "id": "s-b18-2",
        "staffName": "นางอินทิรา  พงษ์กระพัน"
      }
    ]
  },
  {
    "id": "b-b19",
    "code": "B19",
    "name": "อาคาร 19 (อาคารสิริวิชญากร)",
    "floors": 5,
    "description": "สังกัด คณะครุศาสตร์",
    "staffs": [
      {
        "id": "s-b19-1",
        "staffName": "นายวุฒิพงษ์  ชำนาญชัยศรี"
      },
      {
        "id": "s-b19-2",
        "staffName": "นางสาวลลิตา  จะเชนรัมย์"
      }
    ]
  },
  {
    "id": "b-b20",
    "code": "B20",
    "name": "อาคาร 20 (อาคารสิริวิทยเกษตร)",
    "floors": 4,
    "description": "สังกัด คณะเทคโนโลยีการเกษตร",
    "staffs": [
      {
        "id": "s-b20-1",
        "staffName": "นางสาวนงพะงา  ปลั่งกลาง"
      },
      {
        "id": "s-b20-2",
        "staffName": "นางสาวศิริขวัญ  อินัง"
      }
    ]
  },
  {
    "id": "b-b21",
    "code": "B21",
    "name": "อาคาร 21",
    "floors": 3,
    "description": "สังกัด สำนักส่งเสริมวิชาการและงานทะเบียน",
    "staffs": [
      {
        "id": "s-b21-1",
        "staffName": "นางสาวละเมียด  ปลื้มกมล"
      }
    ]
  },
  {
    "id": "b-b22",
    "code": "B22",
    "name": "อาคาร 22 (อาคารวิทยาศาสตร์สุขภาพ)",
    "floors": 8,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b22-1",
        "staffName": "นางสาวศุภิสรา  รอบแคว้น"
      },
      {
        "id": "s-b22-2",
        "staffName": "นางสาวราตรี  คำบาง"
      }
    ]
  },
  {
    "id": "b-b23",
    "code": "B23",
    "name": "อาคาร 23 (อาคารอเนกคุณาคาร 1 อาคารราชภัฏคอมเพลคซ์)",
    "floors": 4,
    "description": "สังกัด สำนักส่งเสริมวิชาการและงานทะเบียน + กองพัฒนานักศึกษา",
    "staffs": [
      {
        "id": "s-b23-1",
        "staffName": "นางอำนวย  คงชู"
      },
      {
        "id": "s-b23-2",
        "staffName": "นายสมชาย  สว่างพบ"
      }
    ]
  },
  {
    "id": "b-b24",
    "code": "B24",
    "name": "อาคาร 24 (คณะวิทยาการจัดการ)",
    "floors": 7,
    "description": "สังกัด คณะวิทยาการจัดการ",
    "staffs": [
      {
        "id": "s-b24-1",
        "staffName": "นางณิสาชล  คะรุรัมย์"
      },
      {
        "id": "s-b24-2",
        "staffName": "นางวาสนา  กรีรัมย์"
      }
    ]
  },
  {
    "id": "b-b25",
    "code": "B25",
    "name": "อาคาร 25 (คณะมนุษยศาสตร์และสังคมศาสตร์)",
    "floors": 5,
    "description": "สังกัด คณะมนุษยศาสตร์และสังคมศาสตร์",
    "staffs": [
      {
        "id": "s-b25-1",
        "staffName": "นางพรรณี  สวายรัมย์"
      },
      {
        "id": "s-b25-2",
        "staffName": "นางวันทนีย์  ประสูติธนกิตต์"
      }
    ]
  },
  {
    "id": "b-b26",
    "code": "B26",
    "name": "อาคาร 26 (อาคารอเนกคุณาคาร 2)",
    "floors": 4,
    "description": "สังกัด คณะครุศาสตร์ + คณะมนุษยศาสตร์ฯ (สาขาวิชาศิลปะ)",
    "staffs": [
      {
        "id": "s-b26-1",
        "staffName": "นางสาวละเมียด  ปลื้มกมล"
      }
    ]
  },
  {
    "id": "b-b27",
    "code": "B27",
    "name": "อาคาร 27 (โรงเรียนสาธิต มหาวิทยาลัยราชภัฏบุรีรัมย์)",
    "floors": 4,
    "description": "สังกัด โรงเรียนสาธิต มหาวิทยาลัยราชภัฏบุรีรัมย์",
    "staffs": [
      {
        "id": "s-b27-1",
        "staffName": "นางสาวสุภาภรณ์  ชะโลมรัมย์"
      }
    ]
  },
  {
    "id": "b-b-lib",
    "code": "B-LIB",
    "name": "อาคารบรรณราชนครินทร์ (ห้องสมุด สำนักวิทยบริการฯ)",
    "floors": 4,
    "description": "สังกัด สำนักวิทยบริการและเทคโนโลยีสารสนเทศ",
    "staffs": [
      {
        "id": "s-b-lib-1",
        "staffName": "นางสาวกันตินันท์  เอกา"
      }
    ]
  },
  {
    "id": "b-b-stad",
    "code": "B-STAD",
    "name": "สนามกีฬากลาง",
    "floors": 1,
    "description": "สังกัด คณะครุศาสตร์",
    "staffs": [
      {
        "id": "s-b-stad-1",
        "staffName": "นายวุฒิชัย  มะลิรัมย์"
      }
    ]
  },
  {
    "id": "b-b-gym",
    "code": "B-GYM",
    "name": "โรงยิมส์",
    "floors": 2,
    "description": "สังกัด คณะครุศาสตร์",
    "staffs": [
      {
        "id": "s-b-gym-1",
        "staffName": "นางสาวจุฑาทิพย์  อีนัง"
      }
    ]
  },
  {
    "id": "b-b-aud1",
    "code": "B-AUD1",
    "name": "หอประชุมวิชชาอัตศาสตร์",
    "floors": 2,
    "description": "ผอ.กองกลาง",
    "staffs": [
      {
        "id": "s-b-aud1-1",
        "staffName": "นายสุรชัย  ตามกลาง"
      }
    ]
  },
  {
    "id": "b-b-aud2",
    "code": "B-AUD2",
    "name": "หอประชุมมาลิณีจุโฑปะมา",
    "floors": 2,
    "description": "คณะกรรมการหอประชุมตามคำสั่งแต่งตั้งของมหาวิทยาลัย",
    "staffs": [
      {
        "id": "s-b-aud2-1",
        "staffName": "นายญาณวรุตม์  พันธุ์ขุนแก้ว"
      },
      {
        "id": "s-b-aud2-2",
        "staffName": "นางสาวบุญมี  ปัตแวว"
      },
      {
        "id": "s-b-aud2-3",
        "staffName": "นางพัชรา  พะสุรัมย์"
      }
    ]
  },
  {
    "id": "b-b-cer",
    "code": "B-CER",
    "name": "อาคารเซรามิกส์",
    "floors": 1,
    "description": "สังกัด คณะเทคโนโลยีอุตสาหกรรม",
    "staffs": [
      {
        "id": "s-b-cer-1",
        "staffName": "นายทองพูน  ธรรมสาลี"
      }
    ]
  },
  {
    "id": "b-b-wood",
    "code": "B-WOOD",
    "name": "Shop งานไม้ (คณะเทคโนโลยีอุตสาหกรรมเก่า)",
    "floors": 1,
    "description": "สังกัด คณะเทคโนโลยีอุตสาหกรรม",
    "staffs": [
      {
        "id": "s-b-wood-1",
        "staffName": "นายทองพูน  ธรรมสาลี"
      }
    ]
  },
  {
    "id": "b-b-it",
    "code": "B-IT",
    "name": "อาคาร IT (อาคารเทคโนโลยีสารสนเทศเก่า)",
    "floors": 2,
    "description": "สังกัด คณะวิทยาศาสตร์",
    "staffs": [
      {
        "id": "s-b-it-1",
        "staffName": "นางณิชาภา  นามวัน"
      }
    ]
  },
  {
    "id": "b-b-cul",
    "code": "B-CUL",
    "name": "ศูนย์วัฒนธรรมอีสานใต้",
    "floors": 2,
    "description": "สังกัด สำนักศิลปะและวัฒนธรรม",
    "staffs": [
      {
        "id": "s-b-cul-1",
        "staffName": "นางสาวเสาวลักษณ์  กอนรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp01",
    "code": "DORM-RP01",
    "name": "หอพักราชพฤกษ์ 1",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp01-1",
        "staffName": "นางสาวนวน  ระตาภรณ์"
      }
    ]
  },
  {
    "id": "b-dorm-rp02",
    "code": "DORM-RP02",
    "name": "หอพักราชพฤกษ์ 2",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp02-1",
        "staffName": "นางสาวศรสวรรค์  เดยังรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp03",
    "code": "DORM-RP03",
    "name": "หอพักราชพฤกษ์ 3",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp03-1",
        "staffName": "นางสาวนวน  ระตาภรณ์"
      }
    ]
  },
  {
    "id": "b-dorm-rp04",
    "code": "DORM-RP04",
    "name": "หอพักราชพฤกษ์ 4",
    "floors": 4,
    "description": "สังกัด คณะพยาบาลศาสตร์ (หอพักนักศึกษาพยาบาล)",
    "staffs": [
      {
        "id": "s-dorm-rp04-1",
        "staffName": "นางสาวศรสวรรค์  เดยังรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp06",
    "code": "DORM-RP06",
    "name": "หอพักราชพฤกษ์ 6",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp06-1",
        "staffName": "นางสาวนงนุช  หนาวบุรีรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp07",
    "code": "DORM-RP07",
    "name": "หอพักราชพฤกษ์ 7",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp07-1",
        "staffName": "นางสาวนงนุช  หนาวบุรีรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp08",
    "code": "DORM-RP08",
    "name": "หอพักราชพฤกษ์ 8",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp08-1",
        "staffName": "นางสาวจรรยา  เจียนรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-rp09",
    "code": "DORM-RP09",
    "name": "หอพักราชพฤกษ์ 9",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-rp09-1",
        "staffName": "นางสาวจรรยา  เจียนรัมย์"
      }
    ]
  },
  {
    "id": "b-dorm-ka",
    "code": "DORM-KA",
    "name": "หอพักเขาอังคาร",
    "floors": 4,
    "description": "สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)",
    "staffs": [
      {
        "id": "s-dorm-ka-1",
        "staffName": "นางพรพรรณ  คำใจ"
      }
    ]
  },
  {
    "id": "b-dorm-kd",
    "code": "DORM-KD",
    "name": "หอพักเขากระโดง",
    "floors": 4,
    "description": "สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (หอพักบุคลากร)",
    "staffs": [
      {
        "id": "s-dorm-kd-1",
        "staffName": "นางพรพรรณ  คำใจ"
      }
    ]
  },
  {
    "id": "b-canteen-1",
    "code": "CANTEEN-1",
    "name": "ศูนย์อาหาร 1",
    "floors": 2,
    "description": "สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (คณะกรรมการศูนย์อาหารตามคำสั่งแต่งตั้งของมหาวิทยาลัย)",
    "staffs": [
      {
        "id": "s-canteen-1-1",
        "staffName": "นายพรชัย  มาลัยทอง"
      }
    ]
  },
  {
    "id": "b-canteen-2",
    "code": "CANTEEN-2",
    "name": "ศูนย์อาหาร 2",
    "floors": 2,
    "description": "สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (คณะกรรมการศูนย์อาหารตามคำสั่งแต่งตั้งของมหาวิทยาลัย)",
    "staffs": [
      {
        "id": "s-canteen-2-1",
        "staffName": "นายพรชัย  มาลัยทอง"
      }
    ]
  },
  {
    "id": "b-pool",
    "code": "POOL",
    "name": "สระว่ายน้ำ (ราชภัฏชลาธาร)",
    "floors": 1,
    "description": "คณะกรรมการอาคารสถานกีฬาตามคำสั่งแต่งตั้งของมหาวิทยาลัย",
    "staffs": [
      {
        "id": "s-pool-1",
        "staffName": "นายวรุฒิพงษ์  สิริวัฒนธีรกุล"
      }
    ]
  }
]

if (!(globalThis as any).__DEFAULT_BUILDINGS) {
  (globalThis as any).__DEFAULT_BUILDINGS = [...INITIAL_BUILDINGS]
}

export default defineEventHandler(async () => {
  if (await isDbReady()) {
    try {
      const buildings = await prisma.building.findMany({
        where: { isActive: true },
        include: { staffs: true },
        orderBy: { code: 'asc' }
      })

      if (buildings.length > 0) {
        return { ok: true, data: buildings }
      }
    } catch (err) {}
  }

  return { ok: true, data: (globalThis as any).__DEFAULT_BUILDINGS }
})
