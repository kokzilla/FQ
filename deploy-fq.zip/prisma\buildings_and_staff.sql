-- =========================================================================
-- SQL Data Script: BRU Buildings & Responsible Staff (Separated Individual Buildings)
-- มหาวิทยาลัยราชภัฏบุรีรัมย์ - ข้อมูลอาคารและผู้รับผิดชอบ (แยกข้อมูลอาคารเดี่ยวครบทุกหลัง)
-- Compatible with PostgreSQL (Table: "Building", "BuildingStaff")
-- =========================================================================

BEGIN;

-- อาคาร: B01 - อาคาร 1
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B01', 'อาคาร 1', 3, 'สังกัด สถาบันวิจัยและพัฒนา', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางประยงค์  นันกลาง', true, NOW()
FROM "Building" b WHERE b."code" = 'B01'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางประยงค์  นันกลาง'
);

-- อาคาร: B02 - อาคาร 2
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B02', 'อาคาร 2', 3, 'สังกัด คณะวิทยาศาสตร์ (ห้องพยาบาล)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวจันทร์จิรา  เชิดกลิ่น', true, NOW()
FROM "Building" b WHERE b."code" = 'B02'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวจันทร์จิรา  เชิดกลิ่น'
);

-- อาคาร: B05 - อาคาร 5
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B05', 'อาคาร 5', 3, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวปัทมา  ยอนรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B05'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวปัทมา  ยอนรัมย์'
);

-- อาคาร: B06 - อาคาร 6
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B06', 'อาคาร 6', 3, 'สังกัด คณะมนุษยศาสตร์และสังคมศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวสุณี  เกริงรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B06'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวสุณี  เกริงรัมย์'
);

-- อาคาร: B07 - อาคาร 7
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B07', 'อาคาร 7', 3, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวพิมพ์วลัญช์  เชียงพฤกษ์', true, NOW()
FROM "Building" b WHERE b."code" = 'B07'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวพิมพ์วลัญช์  เชียงพฤกษ์'
);

-- อาคาร: B10 - อาคาร 10
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B10', 'อาคาร 10', 3, 'สังกัด คณะครุศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวตวงลักษณ์  นิลแก้ว', true, NOW()
FROM "Building" b WHERE b."code" = 'B10'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวตวงลักษณ์  นิลแก้ว'
);

-- อาคาร: B12 - อาคาร 12 (ศูนย์วิทยาศาสตร์และวิทยาศาสตร์ประยุกต์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B12', 'อาคาร 12 (ศูนย์วิทยาศาสตร์และวิทยาศาสตร์ประยุกต์)', 4, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายพงศ์ศรัณย์  เติมเทียน', true, NOW()
FROM "Building" b WHERE b."code" = 'B12'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายพงศ์ศรัณย์  เติมเทียน'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวมะปราง  เปาป่า', true, NOW()
FROM "Building" b WHERE b."code" = 'B12'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวมะปราง  เปาป่า'
);

-- อาคาร: B13 - อาคาร 13 (คณะพยาบาลศาสตร์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B13', 'อาคาร 13 (คณะพยาบาลศาสตร์)', 4, 'สังกัด คณะพยาบาลศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวสุวรรณา  ทองสม', true, NOW()
FROM "Building" b WHERE b."code" = 'B13'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวสุวรรณา  ทองสม'
);

-- อาคาร: B14 - อาคาร 14
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B14', 'อาคาร 14', 3, 'สังกัด คณะครุศาสตร์ + คณะมนุษยศาสตร์ฯ (สาขาวิชานาฏศิลป์+ดนตรี)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวมาลี  สิงห์คำ', true, NOW()
FROM "Building" b WHERE b."code" = 'B14'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวมาลี  สิงห์คำ'
);

-- อาคาร: B15 - อาคาร 15 (อาคารเฉลิมพระเกียรติ 50 พรรษามหาวชิราลงกรณ์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B15', 'อาคาร 15 (อาคารเฉลิมพระเกียรติ 50 พรรษามหาวชิราลงกรณ์)', 9, 'สังกัด สำนักงานอธิการบดี + บัณฑิตวิทยาลัย', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางบุญมี  จันลา', true, NOW()
FROM "Building" b WHERE b."code" = 'B15'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางบุญมี  จันลา'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวธัญรัศม์  เครืองรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B15'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวธัญรัศม์  เครืองรัมย์'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวพชรภรณ์  ลีประโคน', true, NOW()
FROM "Building" b WHERE b."code" = 'B15'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวพชรภรณ์  ลีประโคน'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางรุจิกาญจน์  สิงห์คำ', true, NOW()
FROM "Building" b WHERE b."code" = 'B15'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางรุจิกาญจน์  สิงห์คำ'
);

-- อาคาร: B16 - อาคาร 16 (อาคารสิ่งทอ)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B16', 'อาคาร 16 (อาคารสิ่งทอ)', 2, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางกชพร  ชุบรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B16'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางกชพร  ชุบรัมย์'
);

-- อาคาร: B17 - อาคาร 17 (อาคารนวัตปัญญา)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B17', 'อาคาร 17 (อาคารนวัตปัญญา)', 4, 'สังกัด สำนักวิทยบริการและเทคโนโลยีสารสนเทศ', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวกรวรรณ  จันทรภูมิ', true, NOW()
FROM "Building" b WHERE b."code" = 'B17'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวกรวรรณ  จันทรภูมิ'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางณัฐชยา  ปรีชารัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B17'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางณัฐชยา  ปรีชารัมย์'
);

-- อาคาร: B18 - อาคาร 18 (อาคารเฉลิมพระเกียรติ 7 รอบ พระชนมพรรษา)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B18', 'อาคาร 18 (อาคารเฉลิมพระเกียรติ 7 รอบ พระชนมพรรษา)', 5, 'สังกัด คณะเทคโนโลยีอุตสาหกรรม', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางทองสุข  คิดการ', true, NOW()
FROM "Building" b WHERE b."code" = 'B18'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางทองสุข  คิดการ'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางอินทิรา  พงษ์กระพัน', true, NOW()
FROM "Building" b WHERE b."code" = 'B18'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางอินทิรา  พงษ์กระพัน'
);

-- อาคาร: B19 - อาคาร 19 (อาคารสิริวิชญากร)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B19', 'อาคาร 19 (อาคารสิริวิชญากร)', 5, 'สังกัด คณะครุศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายวุฒิพงษ์  ชำนาญชัยศรี', true, NOW()
FROM "Building" b WHERE b."code" = 'B19'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายวุฒิพงษ์  ชำนาญชัยศรี'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวลลิตา  จะเชนรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B19'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวลลิตา  จะเชนรัมย์'
);

-- อาคาร: B20 - อาคาร 20 (อาคารสิริวิทยเกษตร)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B20', 'อาคาร 20 (อาคารสิริวิทยเกษตร)', 4, 'สังกัด คณะเทคโนโลยีการเกษตร', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวนงพะงา  ปลั่งกลาง', true, NOW()
FROM "Building" b WHERE b."code" = 'B20'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวนงพะงา  ปลั่งกลาง'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวศิริขวัญ  อินัง', true, NOW()
FROM "Building" b WHERE b."code" = 'B20'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวศิริขวัญ  อินัง'
);

-- อาคาร: B21 - อาคาร 21
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B21', 'อาคาร 21', 3, 'สังกัด สำนักส่งเสริมวิชาการและงานทะเบียน', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวละเมียด  ปลื้มกมล', true, NOW()
FROM "Building" b WHERE b."code" = 'B21'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวละเมียด  ปลื้มกมล'
);

-- อาคาร: B22 - อาคาร 22 (อาคารวิทยาศาสตร์สุขภาพ)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B22', 'อาคาร 22 (อาคารวิทยาศาสตร์สุขภาพ)', 8, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวศุภิสรา  รอบแคว้น', true, NOW()
FROM "Building" b WHERE b."code" = 'B22'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวศุภิสรา  รอบแคว้น'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวราตรี  คำบาง', true, NOW()
FROM "Building" b WHERE b."code" = 'B22'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวราตรี  คำบาง'
);

-- อาคาร: B23 - อาคาร 23 (อาคารอเนกคุณาคาร 1 อาคารราชภัฏคอมเพลคซ์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B23', 'อาคาร 23 (อาคารอเนกคุณาคาร 1 อาคารราชภัฏคอมเพลคซ์)', 4, 'สังกัด สำนักส่งเสริมวิชาการและงานทะเบียน + กองพัฒนานักศึกษา', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางอำนวย  คงชู', true, NOW()
FROM "Building" b WHERE b."code" = 'B23'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางอำนวย  คงชู'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายสมชาย  สว่างพบ', true, NOW()
FROM "Building" b WHERE b."code" = 'B23'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายสมชาย  สว่างพบ'
);

-- อาคาร: B24 - อาคาร 24 (คณะวิทยาการจัดการ)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B24', 'อาคาร 24 (คณะวิทยาการจัดการ)', 7, 'สังกัด คณะวิทยาการจัดการ', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางณิสาชล  คะรุรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B24'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางณิสาชล  คะรุรัมย์'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางวาสนา  กรีรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B24'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางวาสนา  กรีรัมย์'
);

-- อาคาร: B25 - อาคาร 25 (คณะมนุษยศาสตร์และสังคมศาสตร์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B25', 'อาคาร 25 (คณะมนุษยศาสตร์และสังคมศาสตร์)', 5, 'สังกัด คณะมนุษยศาสตร์และสังคมศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางพรรณี  สวายรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B25'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางพรรณี  สวายรัมย์'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางวันทนีย์  ประสูติธนกิตต์', true, NOW()
FROM "Building" b WHERE b."code" = 'B25'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางวันทนีย์  ประสูติธนกิตต์'
);

-- อาคาร: B26 - อาคาร 26 (อาคารอเนกคุณาคาร 2)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B26', 'อาคาร 26 (อาคารอเนกคุณาคาร 2)', 4, 'สังกัด คณะครุศาสตร์ + คณะมนุษยศาสตร์ฯ (สาขาวิชาศิลปะ)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวละเมียด  ปลื้มกมล', true, NOW()
FROM "Building" b WHERE b."code" = 'B26'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวละเมียด  ปลื้มกมล'
);

-- อาคาร: B27 - อาคาร 27 (โรงเรียนสาธิต มหาวิทยาลัยราชภัฏบุรีรัมย์)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B27', 'อาคาร 27 (โรงเรียนสาธิต มหาวิทยาลัยราชภัฏบุรีรัมย์)', 4, 'สังกัด โรงเรียนสาธิต มหาวิทยาลัยราชภัฏบุรีรัมย์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวสุภาภรณ์  ชะโลมรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B27'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวสุภาภรณ์  ชะโลมรัมย์'
);

-- อาคาร: B-LIB - อาคารบรรณราชนครินทร์ (ห้องสมุด สำนักวิทยบริการฯ)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-LIB', 'อาคารบรรณราชนครินทร์ (ห้องสมุด สำนักวิทยบริการฯ)', 4, 'สังกัด สำนักวิทยบริการและเทคโนโลยีสารสนเทศ', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวกันตินันท์  เอกา', true, NOW()
FROM "Building" b WHERE b."code" = 'B-LIB'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวกันตินันท์  เอกา'
);

-- อาคาร: B-STAD - สนามกีฬากลาง
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-STAD', 'สนามกีฬากลาง', 1, 'สังกัด คณะครุศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายวุฒิชัย  มะลิรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B-STAD'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายวุฒิชัย  มะลิรัมย์'
);

-- อาคาร: B-GYM - โรงยิมส์
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-GYM', 'โรงยิมส์', 2, 'สังกัด คณะครุศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวจุฑาทิพย์  อีนัง', true, NOW()
FROM "Building" b WHERE b."code" = 'B-GYM'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวจุฑาทิพย์  อีนัง'
);

-- อาคาร: B-AUD1 - หอประชุมวิชชาอัตศาสตร์
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-AUD1', 'หอประชุมวิชชาอัตศาสตร์', 2, 'ผอ.กองกลาง', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายสุรชัย  ตามกลาง', true, NOW()
FROM "Building" b WHERE b."code" = 'B-AUD1'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายสุรชัย  ตามกลาง'
);

-- อาคาร: B-AUD2 - หอประชุมมาลิณีจุโฑปะมา
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-AUD2', 'หอประชุมมาลิณีจุโฑปะมา', 2, 'คณะกรรมการหอประชุมตามคำสั่งแต่งตั้งของมหาวิทยาลัย', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายญาณวรุตม์  พันธุ์ขุนแก้ว', true, NOW()
FROM "Building" b WHERE b."code" = 'B-AUD2'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายญาณวรุตม์  พันธุ์ขุนแก้ว'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวบุญมี  ปัตแวว', true, NOW()
FROM "Building" b WHERE b."code" = 'B-AUD2'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวบุญมี  ปัตแวว'
);
INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางพัชรา  พะสุรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B-AUD2'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางพัชรา  พะสุรัมย์'
);

-- อาคาร: B-CER - อาคารเซรามิกส์
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-CER', 'อาคารเซรามิกส์', 1, 'สังกัด คณะเทคโนโลยีอุตสาหกรรม', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายทองพูน  ธรรมสาลี', true, NOW()
FROM "Building" b WHERE b."code" = 'B-CER'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายทองพูน  ธรรมสาลี'
);

-- อาคาร: B-WOOD - Shop งานไม้ (คณะเทคโนโลยีอุตสาหกรรมเก่า)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-WOOD', 'Shop งานไม้ (คณะเทคโนโลยีอุตสาหกรรมเก่า)', 1, 'สังกัด คณะเทคโนโลยีอุตสาหกรรม', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายทองพูน  ธรรมสาลี', true, NOW()
FROM "Building" b WHERE b."code" = 'B-WOOD'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายทองพูน  ธรรมสาลี'
);

-- อาคาร: B-IT - อาคาร IT (อาคารเทคโนโลยีสารสนเทศเก่า)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-IT', 'อาคาร IT (อาคารเทคโนโลยีสารสนเทศเก่า)', 2, 'สังกัด คณะวิทยาศาสตร์', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางณิชาภา  นามวัน', true, NOW()
FROM "Building" b WHERE b."code" = 'B-IT'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางณิชาภา  นามวัน'
);

-- อาคาร: B-CUL - ศูนย์วัฒนธรรมอีสานใต้
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'B-CUL', 'ศูนย์วัฒนธรรมอีสานใต้', 2, 'สังกัด สำนักศิลปะและวัฒนธรรม', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวเสาวลักษณ์  กอนรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'B-CUL'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวเสาวลักษณ์  กอนรัมย์'
);

-- อาคาร: DORM-RP01 - หอพักราชพฤกษ์ 1
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP01', 'หอพักราชพฤกษ์ 1', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวนวน  ระตาภรณ์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP01'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวนวน  ระตาภรณ์'
);

-- อาคาร: DORM-RP02 - หอพักราชพฤกษ์ 2
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP02', 'หอพักราชพฤกษ์ 2', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวศรสวรรค์  เดยังรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP02'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวศรสวรรค์  เดยังรัมย์'
);

-- อาคาร: DORM-RP03 - หอพักราชพฤกษ์ 3
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP03', 'หอพักราชพฤกษ์ 3', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวนวน  ระตาภรณ์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP03'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวนวน  ระตาภรณ์'
);

-- อาคาร: DORM-RP04 - หอพักราชพฤกษ์ 4
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP04', 'หอพักราชพฤกษ์ 4', 4, 'สังกัด คณะพยาบาลศาสตร์ (หอพักนักศึกษาพยาบาล)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวศรสวรรค์  เดยังรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP04'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวศรสวรรค์  เดยังรัมย์'
);

-- อาคาร: DORM-RP06 - หอพักราชพฤกษ์ 6
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP06', 'หอพักราชพฤกษ์ 6', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวนงนุช  หนาวบุรีรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP06'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวนงนุช  หนาวบุรีรัมย์'
);

-- อาคาร: DORM-RP07 - หอพักราชพฤกษ์ 7
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP07', 'หอพักราชพฤกษ์ 7', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวนงนุช  หนาวบุรีรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP07'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวนงนุช  หนาวบุรีรัมย์'
);

-- อาคาร: DORM-RP08 - หอพักราชพฤกษ์ 8
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP08', 'หอพักราชพฤกษ์ 8', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวจรรยา  เจียนรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP08'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวจรรยา  เจียนรัมย์'
);

-- อาคาร: DORM-RP09 - หอพักราชพฤกษ์ 9
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-RP09', 'หอพักราชพฤกษ์ 9', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางสาวจรรยา  เจียนรัมย์', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-RP09'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางสาวจรรยา  เจียนรัมย์'
);

-- อาคาร: DORM-KA - หอพักเขาอังคาร
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-KA', 'หอพักเขาอังคาร', 4, 'สังกัด กองพัฒนานักศึกษา (หอพักนักศึกษา)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางพรพรรณ  คำใจ', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-KA'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางพรพรรณ  คำใจ'
);

-- อาคาร: DORM-KD - หอพักเขากระโดง
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'DORM-KD', 'หอพักเขากระโดง', 4, 'สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (หอพักบุคลากร)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นางพรพรรณ  คำใจ', true, NOW()
FROM "Building" b WHERE b."code" = 'DORM-KD'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นางพรพรรณ  คำใจ'
);

-- อาคาร: CANTEEN-1 - ศูนย์อาหาร 1
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'CANTEEN-1', 'ศูนย์อาหาร 1', 2, 'สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (คณะกรรมการศูนย์อาหารตามคำสั่งแต่งตั้งของมหาวิทยาลัย)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายพรชัย  มาลัยทอง', true, NOW()
FROM "Building" b WHERE b."code" = 'CANTEEN-1'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายพรชัย  มาลัยทอง'
);

-- อาคาร: CANTEEN-2 - ศูนย์อาหาร 2
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'CANTEEN-2', 'ศูนย์อาหาร 2', 2, 'สังกัด ฝ่ายทรัพย์สินและสิทธิประโยชน์ (คณะกรรมการศูนย์อาหารตามคำสั่งแต่งตั้งของมหาวิทยาลัย)', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายพรชัย  มาลัยทอง', true, NOW()
FROM "Building" b WHERE b."code" = 'CANTEEN-2'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายพรชัย  มาลัยทอง'
);

-- อาคาร: POOL - สระว่ายน้ำ (ราชภัฏชลาธาร)
INSERT INTO "Building" ("id", "code", "name", "floors", "description", "isActive", "createdAt", "updatedAt")
VALUES (gen_random_uuid(), 'POOL', 'สระว่ายน้ำ (ราชภัฏชลาธาร)', 1, 'คณะกรรมการอาคารสถานกีฬาตามคำสั่งแต่งตั้งของมหาวิทยาลัย', true, NOW(), NOW())
ON CONFLICT ("code") DO UPDATE SET
  "name" = EXCLUDED."name",
  "floors" = EXCLUDED."floors",
  "description" = EXCLUDED."description",
  "updatedAt" = NOW();

INSERT INTO "BuildingStaff" ("id", "buildingId", "staffName", "isPrimary", "createdAt")
SELECT gen_random_uuid(), b."id", 'นายวรุฒิพงษ์  สิริวัฒนธีรกุล', true, NOW()
FROM "Building" b WHERE b."code" = 'POOL'
AND NOT EXISTS (
  SELECT 1 FROM "BuildingStaff" bs WHERE bs."buildingId" = b."id" AND bs."staffName" = 'นายวรุฒิพงษ์  สิริวัฒนธีรกุล'
);

COMMIT;
